import os

directory = '/home/my/Documents/Sampreeth/SR/PlantVillage/Dataset/Potato___Late_blight'

for filename in os.listdir(directory):
    if filename.endswith('.JPG'):
        new_filename = os.path.join(directory, filename.lower())
        os.rename(os.path.join(directory, filename), new_filename)
        print(f'Renamed: {filename} -> {new_filename}')
