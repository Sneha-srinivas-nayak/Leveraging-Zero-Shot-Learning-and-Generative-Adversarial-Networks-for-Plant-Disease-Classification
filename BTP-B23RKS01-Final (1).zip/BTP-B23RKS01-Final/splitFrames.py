import os
import cv2

# Path to the directory containing the framed images
framed_images_directory = '/home/my/Documents/Sampreeth/SR/StyleGan/Late_blight/default'

# Path to the directory where you want to save the individual leaves
generated_folder = '/home/my/Documents/Sampreeth/SR/Potato___Late_blight'

# Create the generated folder if it doesn't exist
os.makedirs(generated_folder, exist_ok=True)

# Function to split a framed image into individual leaves and resize to 256x256 pixels
def split_framed_image(image_path):
    framed_image = cv2.imread(image_path)
    height, width, _ = framed_image.shape
    leaf_height = height // 8
    leaf_width = width // 8
    target_size = (256, 256)

    for row in range(8):
        for col in range(8):
            leaf = framed_image[row * leaf_height:(row + 1) * leaf_height,
                                col * leaf_width:(col + 1) * leaf_width]

            # Resize the leaf to 256x256 pixels
            leaf = cv2.resize(leaf, target_size)

            leaf_filename = os.path.splitext(os.path.basename(image_path))[0] + f'_leaf_{row}_{col}.jpg'
            leaf_path = os.path.join(generated_folder, leaf_filename)
            cv2.imwrite(leaf_path, leaf)

# Iterate through the framed images and split them
for framed_image_filename in os.listdir(framed_images_directory):
    framed_image_path = os.path.join(framed_images_directory, framed_image_filename)
    split_framed_image(framed_image_path)

