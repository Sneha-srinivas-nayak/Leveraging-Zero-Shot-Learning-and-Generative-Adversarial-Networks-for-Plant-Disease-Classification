There are 10 code files where all are interrelated

Firstly consider a dataset and give it as input for Preprocessed.py to convert the images into numpy format.

If the traning dataset is smaller or classes imbalanced then styleGan.py or dcgan.py is used to generate synthetic images to make the classes balanced

count.py is used to count the no.of images with in the specified folder and splitFrames.py is used to split frames into images that are generated from gan python files in the Results Folder

ssim.py is structural similarity index used to extract the best generated synthetic images that closely resemble the training dataset.

segmented.py and segmented2.py files are used for segmentation techniques and augmentation.py are augmentation techniques used when the model is tested against other datasets

transferLearning.py is main file that gives the accuracy for 12 models for 25 epochs given the training and testing final preprocessed data performing all the given techniques.


