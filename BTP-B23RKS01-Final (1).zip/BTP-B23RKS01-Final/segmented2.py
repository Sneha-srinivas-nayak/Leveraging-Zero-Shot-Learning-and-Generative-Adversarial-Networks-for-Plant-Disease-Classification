import os
import cv2
import numpy as np
import sys

import torch
import torch.nn as nn
import torch.nn.functional as F

import matplotlib.pyplot as plt
from IPython import display
display.set_matplotlib_formats('svg')

import torchvision.transforms as transforms
from torch.utils.data import DataLoader, Subset

from PIL import Image
import pickle
import numpy as np
from skimage.transform import resize

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


url = '/home/my/Documents/Sampreeth/SR/archive/Augmented/Dataset/train/'

classes = ['Tomato__Early_blight', 'Tomato__Late_blight']
classes = np.array(classes)

data = []
label = []
new_shape = (64, 64)

# Function to extract the leaf from an image
def extract_leaf(image):
    # Convert the image to grayscale
    gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)

    # Apply a threshold to create a binary mask
    _, thresh = cv2.threshold(gray, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)

    # Find contours in the binary mask
    contours, _ = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # Assuming the largest contour is the leaf
    if contours:
        largest_contour = max(contours, key=cv2.contourArea)
        mask = np.zeros_like(gray)
        cv2.drawContours(mask, [largest_contour], 0, 255, thickness=cv2.FILLED)
        result = cv2.bitwise_and(image, image, mask=mask)
        return result
    else:
        return image

for i, cls in enumerate(classes):
    url1 = url + "/" + cls + "/"
    class_data = os.listdir(url1)
    print(class_data)
    # Loop through all image files and store the leaf part in the numpy array
    for j, img in enumerate(class_data):
        image = Image.open(os.path.join(url1, img))
        image = image.convert("RGB")
        
        # Extract the leaf part of the image
        leaf_image = extract_leaf(np.array(image))
        
        # Resize the extracted leaf image to the desired shape
        leaf_image = resize(leaf_image, new_shape)
        
        data.append(leaf_image)
        label.append(i)

np.save('/home/my/Documents/Sampreeth/SR/End/classesS2T_Train.npy', np.array(classes))
np.save('/home/my/Documents/Sampreeth/SR/End/dataS2T_Train.npy', np.array(data))
np.save('/home/my/Documents/Sampreeth/SR/End/labelS2T_Train.npy', np.array(label))
