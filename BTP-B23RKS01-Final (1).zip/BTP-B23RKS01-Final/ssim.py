import os
import cv2
import numpy as np
from skimage.metrics import structural_similarity as ssim

def calculate_ssim(img1, img2):
   gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
   gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
   
   score, _ = ssim(gray1, gray2, full = True)
   
   return score
   
def elect_images(actual_folder, generated_folder, num_selected = 10):
   actual_images = [f for f in os.listdir(actual_folder) if f.endswith(".png")]
   generates_images = [f for f in os.listdir(generated_folder) if f.endswith(".png")]

   selected_images = []
   
   for actual_image in actual_images:
      actual_path = os.path.join(actual_folder, actual_image)
      actual_img = cv2.imread(actual_path)
      
      best_match = None
      best_ssim = -1
      
      for generated_image in generated_images:
         generated_path = os.path.join(generated_folder, generated_image)
         generated_img = cv2.imread(generated_path)
         
         current_ssim = calculate_ssim(actual_img, generated_img)
         
         if current_ssim > best_ssim:
            best_ssim = current_ssim
            best_match = generated_image
            
      selected_images.append(best_match)
      
   return selected_images[:num_selected]
   
   
if _name_ == "__main__":
   actual_dataset_folder = "path_to_dataset_folder"
   combined_generated-folder = "path_to_combined_generated_folder"
   num_selected_images = 10
   
   selected_images = select_images(actual_dataset_folder, combined_generated_folder, num_selected_images)
   
   print("Selected Images:")
   for image in selected_images:
   print(image)
