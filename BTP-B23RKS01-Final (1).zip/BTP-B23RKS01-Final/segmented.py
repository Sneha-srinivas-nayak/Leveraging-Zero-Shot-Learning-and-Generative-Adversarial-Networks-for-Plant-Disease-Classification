import os
import cv2
import numpy as np
import sys

import torch
import torch.nn as nn
import torch.nn.functional as F

import matplotlib.pyplot as plt
from IPython import display
#display.set_matplotlib_formats('svg')

import torchvision.transforms as transforms

from torch.utils.data import DataLoader,Subset

from PIL import Image
from skimage import io
from skimage.color import rgb2gray
from skimage.filters import threshold_otsu
from skimage.measure import label, regionprops
from skimage.measure import label as skimage_label, regionprops
from skimage.morphology import closing, square
from skimage.transform import resize

# Define the path to your dataset and classes
dataset_path = '/home/my/Documents/Sampreeth/SR/archive/Augmented/Dataset/train'
classes = ['Tomato___Early_blight', 'Tomato___Late_blight']

# Define the target shape for your preprocessed images
new_shape = (64, 64)

data = []
labels = []

for i, cls in enumerate(classes):
    class_path = os.path.join(dataset_path, cls)
    class_data = os.listdir(class_path)

    for img_name in class_data:
        img_path = os.path.join(class_path, img_name)
        image = io.imread(img_path)
        
        # Convert to grayscale
        gray_image = rgb2gray(image)
        
        # Apply Otsu's thresholding to separate foreground (leaf) from background
        threshold_value = threshold_otsu(gray_image)
        binary_image = gray_image > threshold_value
        
        # Apply morphological closing to clean up the binary mask
        clean_mask = closing(binary_image, square(3))
        
        # Label connected components in the mask
        labeled_mask = skimage_label(clean_mask)
        
        # Find the largest connected component (the leaf)
        regions = regionprops(labeled_mask)
        largest_region = max(regions, key=lambda region: region.area)
        
        # Extract the bounding box of the leaf
        minr, minc, maxr, maxc = largest_region.bbox
        
        # Crop and resize the leaf image
        leaf_image = image[minr:maxr, minc:maxc]
        resized_leaf_image = resize(leaf_image, new_shape)
        
        data.append(resized_leaf_image)
        labels.append(i)

# Save preprocessed data and labels
np.save('/home/my/Documents/Sampreeth/SR/End/2classesTS_Train.npy', np.array(classes))
np.save('/home/my/Documents/Sampreeth/SR/End/2dataTS_Train.npy', np.array(data))
np.save('/home/my/Documents/Sampreeth/SR/End/2labelTS_Train.npy', np.array(labels))

