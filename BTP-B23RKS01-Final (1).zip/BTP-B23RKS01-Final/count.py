import os
from PIL import Image

# Specify the directory path where your images are located
directory_path = '/home/my/Documents/Sampreeth/SR/Potato___Early_blight'

# Define a list of file extensions that are considered as image files
image_extensions = [".jpg", ".jpeg", ".png", ".gif", ".bmp", ".tiff", ".webp"]

# Initialize a counter for the number of image files
image_count = 0

# Loop through all files in the directory
for filename in os.listdir(directory_path):
    # Check if the file has one of the image extensions
    if any(filename.lower().endswith(ext) for ext in image_extensions):
        # Attempt to open the file as an image using PIL
        try:
            with Image.open(os.path.join(directory_path, filename)) as img:
                # If the file can be opened as an image, increment the count
                image_count += 1
        except Exception as e:
            # Handle any errors that may occur while opening the file
            print(f"Error processing {filename}: {e}")

# Print the total number of image files found
print(f"Total number of image files in {directory_path}: {image_count}")

